#!/bin/bash

java -jar tvrss.jar
